print("i have testicular cancer meow")
