#pragma once

#define _USE_MATH_DEFINES
#include <cmath>

#define IMGUI_DEFINE_MATH_OPERATORS

namespace antagonist
{
	namespace roblox
	{
		void hook_esp();
	}
}