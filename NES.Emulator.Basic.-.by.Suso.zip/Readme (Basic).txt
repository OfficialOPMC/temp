NES Emulation in Minecraft, by Suso (https://www.youtube.com/SusoYT | https://twitter.com/5usos)
Made to be used with Minecraft 1.16.X, may work with future versions.

- Set your resolution to 640×480 from the launcher profiles and play in windowed mode. (Setting the resolution from the graphics menu and then using fullscreen is an alternative, but things may look blurry)
- Enter the world with your graphics set to Fabulous. (It may take a while to load, allow up to 5 minutes)

Controls:
    DPAD - Minecraft movement
    A - Move scroll wheel
    B - Move camera (moving it too fast could input other buttons if your frame rate is too low)
    START - Use Item/Place Block
    SELECT - Attack/Destroy

    I'd recommend using software to remap a controller to these actions (I use JoyToKey https://joytokey.net/en/download).

This was tested on vanilla Minecraft, using mods such as Optifine may prevent it from working.

Packed in with Nestest, by Kevin Horton.
If you want to test other ROMs, convert them using ROM.py (Inluded in world/resources.zip/assets/minecaft/textures/effect/roms or in the advanced version of this release).