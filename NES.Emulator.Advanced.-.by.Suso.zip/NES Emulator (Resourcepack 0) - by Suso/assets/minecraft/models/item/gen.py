from PIL import Image
import json
import os
import glob

def main():
    with open('diamond_hoe.json', 'a') as f:
        for i in range(256):
            stuff = { "predicate": { "custom_model_data": i}, "model": "input/" + '{:02x}'.format(i) }
            f.write(json.dumps(stuff))
            f.write(",\n\t\t")

if __name__ == "__main__":
    main()