from PIL import Image
import json
import os
import glob

def main():
    for i in range(256):
        with open('{:02x}.json'.format(i), 'a') as f:
            stuff = {"parent":"input/root","textures":{"0":"input/" + '{:02x}'.format(i)}}
            f.write(json.dumps(stuff))

if __name__ == "__main__":
    main()