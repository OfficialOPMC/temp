from PIL import Image
import os
import glob

def main():
    for i in range(256):
        img = Image.new('RGB', (1, 1), (255, 0, i))
        img.save('{:02x}.png'.format(i))

if __name__ == "__main__":
    main()