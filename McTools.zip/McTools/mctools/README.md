# McUtils

Utilities to decrypt Minecraft Marketplace Contents

All code and binaries are entered into the Public Domain